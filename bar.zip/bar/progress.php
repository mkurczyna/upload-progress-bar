<?php
session_start();

$key = ini_get("session.upload_progress.prefix") . "measure";
if (!empty($_SESSION[$key])) {
    $loaded = $_SESSION[$key]["bytes_processed"];
    $tSize = $_SESSION[$key]["content_length"];
    echo $loaded < $tSize ? ceil($loaded/$tSize*100) : 100;
}
else {
    echo 100;
}

?>