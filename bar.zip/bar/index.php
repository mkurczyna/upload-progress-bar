<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_FILES["file"])) {
    foreach($_FILES['file']['name'] as $key => $name) {
        $ext = strtolower(pathinfo($name,PATHINFO_EXTENSION));
        $size = $_FILES['file']['size'][$key];
        $db = new SQLite3('list.db');
        $results = $db->query("SELECT ID FROM Files ORDER BY ID DESC limit 1");
        $next = 1;
        while($row = $results->fetchArray()) { $next = $row['ID'] + 1; }
        $newFile="uploads/".$next.'.'.$ext;
        $uploadOk = 1;
        if($size>2147483648) { $uploadOk = 0; echo "The files can't exceed 2GB!"; }
        if($ext != "doc" && $ext != "docx" && $ext != "pdf" ) { $uploadOk = 0; echo "Sorry, only DOC, DOCX & PDF files are allowed."; }
        if($uploadOk) {
            if(move_uploaded_file($_FILES["file"]["tmp_name"][$key], $newFile))
                $results = $db->query("INSERT INTO Files(Name, Size, Extension) VALUES ('".$name."','".$size."','".$ext."')");
            else echo "Sorry, sth went wrong.";    
        }
    }	
}
?>
<!DOCTYPE html>
<HTML>
 <HEAD>
  <TITLE>Upload Files</TITLE>
  <META CHARSET=UTF-8>
  <LINK REL=stylesheet HREF=style.css>
 </HEAD>
 <BODY>
  <SECTION ID=progress><SPAN ID=status></SPAN></SECTION>  
  <FORM ACTION="<?php echo $_SERVER["PHP_SELF"]; ?>" METHOD=POST ENCTYPE=multipart/form-data ONSUBMIT=sendRequest(); ID=formidable>
   <INPUT TYPE=hidden VALUE=measure NAME="<?php echo ini_get("session.upload_progress.name"); ?>">
   <INPUT TYPE=file NAME=file[] ID=file ONCHANGE=validate(); MULTIPLE=multiple ACCEPT=.doc,.docx,.pdf,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document><BR>
   <INPUT TYPE=submit VALUE="Upload files">
  </FORM>
  <SCRIPT SRC=script.js></SCRIPT>
  <BR> Uploaded Files: 
  <TABLE>
  <?php 
        $db = new SQLite3('list.db');
        $results = $db->query("SELECT * FROM Files"); 
        $count = 0;
        while ($row = $results->fetchArray()) { 
            $count++;		
            extract($row); 
            echo "<TR>";
            echo '<TD><A HREF=uploads/'.$ID.'.'.$Extension.' download="'.$Name.'">'.$Name.'</TD>';
            if($Size<1024) $displaySize = $Size." B";
            else if($Size<1048576) $displaySize = round($Size/1024,1)." KB";
            else if($Size<1073741824) $displaySize = round($Size/1048576,1)." MB"; 
            else $displaySize = round($Size/1073741824,1)." GB";
            echo "<TD>".$displaySize."</TD>";
            echo "</TR>";
        } if($count===0) echo "None.";
  ?>
  </TABLE>
 </BODY>
</HTML>