function validate() {
    let files = new Array;
    files = document.getElementById('file').files;
    let wrong = 0;
    Array.prototype.forEach.call(files, element => { 
        let shattered = element.name.split('.');
        let ext = shattered[shattered.length-1].toLowerCase();
        let fSize = element.size;
        if(fSize>2147483648||(ext!=="pdf"&&ext!=="doc"&&ext!=="docx")) wrong = 1;       
    });
    if(wrong) {
        document.getElementById('formidable').reset();
        alert("Only DOC, DOCX & PDF files up to 2GB are allowed!");
    }
}

function sendRequest() {
    let http = new XMLHttpRequest(); 
    http.open("GET", "progress.php");
    http.onreadystatechange = function () { handleResponse(http); };
    http.send(null);
}

function handleResponse(http) {
    let response;
    if (http.readyState == 4) {
        response = http.responseText;
        document.getElementById("progress").style.width = response + "%";
        document.getElementById("status").innerHTML = response + "%";
        if (response < 100) setTimeout("sendRequest()", 500);
    }
}